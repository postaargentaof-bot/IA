# Oferta activa

**Reglas:** `reglas/03-oferta.md`, `04-producto.md` y `05-tienda-y-landing.md`.

Se completa cuando se elige la oferta (etapa 5 del embudo).

| Pieza | Nombre | Precio | Qué es | Archivo |
|---|---|---|---|---|
| Producto principal | — | — | — | — |
| Bono 1 | — | — | — | — |
| Bono 2 | — | — | — | — |
| Bump | — | — | — | — |
| Upsell | — | — | — | — |
| Downsell | — | — | — | — |

- **Promesa** (de A a B y en cuánto tiempo): —
- **Garantía:** —
- **Oferta que se modeló** (con su link y lo que se copió del ángulo y de la estructura, nunca el texto): —

## Voz del cliente

Frases reales de compradores y de comentarios, con su fecha y de dónde salen. Sirven para ganchos, para la landing y para el FAQ.
