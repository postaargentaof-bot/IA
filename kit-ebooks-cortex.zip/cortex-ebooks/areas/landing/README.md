# Landing y checkout

**Reglas:** `reglas/05-tienda-y-landing.md` y `09-reglas-de-juego.md`.

| | |
|---|---|
| URL publicada | — |
| Plataforma | — |
| Última versión publicada | — (fecha y qué cambió) |
| Última compra de prueba | — (fecha y si el evento Compra llegó a Resumen) |

Cada versión se guarda como `versiones/AAAA-MM-DD.html`, con una línea que diga qué cambió y por qué. **Antes de publicar, pasa por el `revisor`.**
