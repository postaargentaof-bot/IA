# Tareas

> El tablero, con una fila por tarea.
> - **Estado:** por hacer, en curso o hecho.
> - **Quién:** {{NOMBRE}} o Claude.
> - **Chat:** el nombre corto del chat que la trabaja.
>
> Cada chat edita solo la fila de su tarea. Lo hecho baja a «Hecho» con una línea de nota. Una vez por mes, lo hecho pasa a `archivo/tareas-AAAA-MM.md`.

## En curso

| Tarea | Área | Quién | Para cuándo | Chat | Nota |
|---|---|---|---|---|---|

## Por hacer

| Tarea | Área | Quién | Para cuándo | Chat | Nota |
|---|---|---|---|---|---|
| Entrevista de arranque | general | Claude | Día 1 | — | `/arranque` |
| Bajar el cerebro de Bilbao y subirlo al repo | sistema | {{NOMBRE}} | Día 1 | — | `EMPEZA-ACA.md`, paso 3 |
| Armar Meta: Business Manager, página, Instagram, cuenta publicitaria, píxel, 2FA y tarjeta en dólares | campanas | {{NOMBRE}} | Semana 1 | — | Checklist en `reglas/06-meta.md` |
| Primera caza de ofertas | ofertas | Claude | Semana 1 | — | Skill `buscar-ofertas` (viene con el cerebro de Bilbao) y `reglas/03-oferta.md` |

## Hecho

| Tarea | Área | Quién | Hecho el | Nota |
|---|---|---|---|---|
