# Estado · SIN ARRANCAR

> Una página. Se reescribe al final de cada tarea; no se acumula. Lo viejo va a `decisiones.md` o se borra. Las tareas viven en `tareas.md`, no acá.

## En una línea

**SIN ARRANCAR.** Abrí un chat sobre este repo y escribí: «Hola, arranquemos. Haceme la entrevista de arranque».

## Números

| | Valor |
|---|---|
| Oferta activa | — |
| Precio del front | — |
| Equilibrio (lo máximo que se puede pagar por venta) | — |
| Ventas reales, últimos 7 días | — |
| Pauta, últimos 7 días | — |
| Ganancia, últimos 7 días | — |

## Campañas

—

## Esta semana, lo que más importa

1. Entrevista de arranque.
2. Bajar el cerebro de Bilbao y subirlo al repo (`EMPEZA-ACA.md`, paso 3).

## Próximas fechas

—
